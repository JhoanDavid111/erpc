/**
 * @license Highcharts JS v9.2.2 (2021-08-24)
 * @module highcharts/modules/oldie
 * @requires highcharts
 *
 * Old IE (v6, v7, v8) module for Highcharts v6+.
 *
 * (c) 2010-2021 Highsoft AS
 * Author: Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/Oldie/Oldie.js';
